Buy Now Button in Website v12
=============================

The module add a button to shope page that helps to purchase single product directly.it cannot redirect to cart. Select a procuct and click on the button it can redirect to confirmation page of the Ecommerce website.


Features
========

* Available in Odoo 12.0 community edition .
* The module help quick checkout for buyers looking to buy a single product at a time.
* When 'Buy Now' button clicked a new cart will create and add the entire product and directly moved to confirmation page of the website
* Keeps existing cart product.



Depends
=======
[Website] addon Odoo


Tech
====
* [XML] - Odoo views
* [JS] - Odoo views
* [Python] - Controllers



Installation
============
- www.odoo.com/documentation/12.0/setup/install.html
- Install our custom addon


License
=======
GNU LGPL, Version 3 (LGPLv3)
(http://www.gnu.org/licenses/agpl.html)


Bug Tracker
===========

Contact odoo@cybrosys.com


Authors
-------
* MuhammedMukthar.N, odoo@cybrosys.com

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.
