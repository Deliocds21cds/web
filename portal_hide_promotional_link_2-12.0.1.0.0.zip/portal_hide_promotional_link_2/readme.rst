.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: https://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

==============================
Portal hide promotional link 2
==============================

 -Con la instalación de este módulo se consigue ocultar la línea "Con la
 tecnología de Odoo" en la vista de los pedidos de compra del portal.
