
Portal hide promotional link 2
============================

With this mod it is possible to hide the two promotional link 
in the Portal purchase invoice view. On
the left and bottom right.

Odoo 12.0
