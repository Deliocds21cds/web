This module extends the functionality of e-Commerce to suggest
the buyer to log in or create an account, but without forcing him to do it.

This way you can avoid duplication of partners in your database and offer your
users a better experience without blocking 1-time buyers.

However, the *Process Checkout* button is not highlighted, to
implicitly encourage users to create the account or log in.
