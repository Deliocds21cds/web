To use this module, you need to:

* Log out.
* Buy something from your website.
* Go to your cart.

There you will see the new options.
