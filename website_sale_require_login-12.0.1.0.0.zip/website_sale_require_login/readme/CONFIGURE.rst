You probably want to enable any user to sign up:

* Go to *Settings > General Settings > Website > Customer Account*.
* Enable *Free sign up*.
