# -*- coding: utf-8 -*-
#################################################################################
# Author      : POWr (<www.powr.io>)
# Copyright(c): 2019-Present POWr Inc.
# All Rights Reserved.
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#################################################################################



# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
