# -*- coding: utf-8 -*-
# Part of AppJetty. See LICENSE file for full copyright and licensing details.

from . import sale_order
from . import customer_order_delivery_config
